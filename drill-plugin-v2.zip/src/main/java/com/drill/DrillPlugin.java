package com.drill;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Container;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class DrillPlugin extends JavaPlugin implements Listener, CommandExecutor {

    private static final int MIN_SIZE = 3;
    private static final int MAX_SIZE = 15;
    private static final int[] SPEEDS = {8, 4, 2, 1};              // ticks between slices
    private static final String[] SPEED_NAMES = {"Slow", "Normal", "Fast", "Turbo"};
    private static final double MOVE_STEP = 0.30;                  // blocks per tick (smooth walking)
    private static final float YAW_STEP = 10f;                     // degrees per tick (smooth turning)
    private static final float PITCH_STEP = 6f;

    private final Map<UUID, Session> sessions = new HashMap<>();

    private static class Session {
        int size = 9;
        boolean forward = false;   // false = dig down, true = dig forward
        boolean autoMove = true;
        int speedIndex = 1;
        BukkitTask task;
        BlockFace face = BlockFace.NORTH;
        Location center;           // center of the slice that will be dug next
        int dug = 0;
        long ticks = 0;
    }

    private static class DrillMenu implements InventoryHolder {
        private Inventory inv;
        @Override
        public Inventory getInventory() { return inv; }
    }

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("drill").setExecutor(this);
    }

    @Override
    public void onDisable() {
        for (Session s : sessions.values()) stop(s);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        openMenu(p);
        return true;
    }

    // ======================= GUI =======================

    private void openMenu(Player p) {
        Session s = sessions.computeIfAbsent(p.getUniqueId(), k -> new Session());
        DrillMenu holder = new DrillMenu();
        Inventory inv = Bukkit.createInventory(holder, 27,
                Component.text("Drill", NamedTextColor.GOLD, TextDecoration.BOLD));
        holder.inv = inv;
        render(inv, s);
        p.openInventory(inv);
    }

    private void render(Inventory inv, Session s) {
        ItemStack pane = item(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "));
        for (int i = 0; i < 27; i++) inv.setItem(i, pane);

        boolean running = s.task != null;
        if (running) {
            inv.setItem(10, item(Material.RED_CONCRETE,
                    Component.text("STOP", NamedTextColor.RED, TextDecoration.BOLD),
                    Component.text("Click to stop drilling", NamedTextColor.GRAY)));
        } else {
            inv.setItem(10, item(Material.LIME_CONCRETE,
                    Component.text("START", NamedTextColor.GREEN, TextDecoration.BOLD),
                    Component.text("Click to start drilling", NamedTextColor.GRAY)));
        }

        inv.setItem(11, item(s.forward ? Material.ARROW : Material.HOPPER,
                Component.text("Direction: " + (s.forward ? "Forward" : "Down"), NamedTextColor.AQUA, TextDecoration.BOLD),
                Component.text("Click to switch (when stopped)", NamedTextColor.GRAY)));

        ItemStack sizeItem = item(Material.GOLD_BLOCK,
                Component.text("Size: " + s.size + " x " + s.size, NamedTextColor.GOLD, TextDecoration.BOLD),
                Component.text("Left click: bigger", NamedTextColor.GRAY),
                Component.text("Right click: smaller", NamedTextColor.GRAY),
                Component.text("(" + MIN_SIZE + " to " + MAX_SIZE + ", when stopped)", NamedTextColor.DARK_GRAY));
        sizeItem.setAmount(s.size);
        inv.setItem(13, sizeItem);

        inv.setItem(15, item(Material.CLOCK,
                Component.text("Speed: " + SPEED_NAMES[s.speedIndex], NamedTextColor.YELLOW, TextDecoration.BOLD),
                Component.text("Click to change", NamedTextColor.GRAY)));

        inv.setItem(16, item(s.autoMove ? Material.IRON_BOOTS : Material.LEATHER_BOOTS,
                Component.text("Auto-move: " + (s.autoMove ? "ON" : "OFF"),
                        s.autoMove ? NamedTextColor.GREEN : NamedTextColor.RED, TextDecoration.BOLD),
                Component.text("Walks you along smoothly", NamedTextColor.GRAY),
                Component.text("when blocks are out of reach", NamedTextColor.GRAY)));

        inv.setItem(22, item(Material.NETHERITE_PICKAXE,
                Component.text("Drill " + s.size + "x" + s.size, NamedTextColor.GOLD, TextDecoration.BOLD),
                Component.text("Blocks dug: " + s.dug, NamedTextColor.GRAY)));
    }

    private ItemStack item(Material m, Component name, Component... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (Component c : lore) l.add(c.decoration(TextDecoration.ITALIC, false));
            meta.lore(l);
        }
        it.setItemMeta(meta);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof DrillMenu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() != e.getInventory()) return;
        Session s = sessions.computeIfAbsent(p.getUniqueId(), k -> new Session());
        boolean running = s.task != null;

        switch (e.getSlot()) {
            case 10 -> {
                if (running) {
                    stop(s);
                    p.sendMessage(Component.text("Drill stopped. Blocks dug: " + s.dug, NamedTextColor.RED));
                } else {
                    start(p, s);
                }
            }
            case 11 -> {
                if (!running) s.forward = !s.forward;
            }
            case 13 -> {
                if (!running) {
                    if (e.getClick().isRightClick()) s.size = Math.max(MIN_SIZE, s.size - 2);
                    else s.size = Math.min(MAX_SIZE, s.size + 2);
                }
            }
            case 15 -> s.speedIndex = (s.speedIndex + 1) % SPEEDS.length;
            case 16 -> s.autoMove = !s.autoMove;
            default -> { return; }
        }
        render(e.getInventory(), s);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof DrillMenu) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Session s = sessions.remove(e.getPlayer().getUniqueId());
        if (s != null) stop(s);
    }

    // ======================= Drilling =======================

    private void start(Player p, Session s) {
        s.dug = 0;
        s.ticks = 0;
        s.face = facingOf(p);
        Block feet = p.getLocation().getBlock();
        if (s.forward) {
            s.center = feet.getLocation().add(s.face.getModX(), 0, s.face.getModZ());
        } else {
            s.center = feet.getRelative(BlockFace.DOWN).getLocation();
        }
        if (s.task != null) s.task.cancel();
        s.task = Bukkit.getScheduler().runTaskTimer(this, () -> tick(p, s), 0L, 1L);
        p.sendMessage(Component.text("Drill started: " + s.size + "x" + s.size
                + (s.forward ? " forward" : " down") + ".", NamedTextColor.GREEN));
    }

    private void stop(Session s) {
        if (s.task != null) {
            s.task.cancel();
            s.task = null;
        }
    }

    private void halt(Player p, Session s, String reason) {
        stop(s);
        p.sendMessage(Component.text("Drill stopped: " + reason + " (" + s.dug + " blocks)", NamedTextColor.RED));
    }

    private BlockFace facingOf(Player p) {
        float yaw = (p.getLocation().getYaw() % 360 + 360) % 360;
        if (yaw >= 315 || yaw < 45) return BlockFace.SOUTH;
        if (yaw < 135) return BlockFace.WEST;
        if (yaw < 225) return BlockFace.NORTH;
        return BlockFace.EAST;
    }

    private float yawOf(BlockFace f) {
        return switch (f) {
            case SOUTH -> 0f;
            case WEST -> 90f;
            case NORTH -> 180f;
            default -> 270f;
        };
    }

    /** Where the player should stand while the current slice is dug. */
    private Location standSpot(Session s) {
        World w = s.center.getWorld();
        double x = s.center.getBlockX() + 0.5;
        double z = s.center.getBlockZ() + 0.5;
        if (!s.forward) {
            return new Location(w, x, s.center.getBlockY() + 1, z);
        }
        return new Location(w, x - s.face.getModX(), s.center.getBlockY(), z - s.face.getModZ());
    }

    /** Distance used for "is the player close enough". Forward mode ignores height. */
    private double gap(Location cur, Location stand, Session s) {
        double dx = stand.getX() - cur.getX();
        double dz = stand.getZ() - cur.getZ();
        double dy = s.forward ? 0 : stand.getY() - cur.getY();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private float approachAngle(float cur, float target, float maxStep) {
        float diff = ((target - cur + 540f) % 360f) - 180f;
        if (Math.abs(diff) <= maxStep) return target;
        return cur + Math.signum(diff) * maxStep;
    }

    private float approach(float cur, float target, float maxStep) {
        float diff = target - cur;
        if (Math.abs(diff) <= maxStep) return target;
        return cur + Math.signum(diff) * maxStep;
    }

    /** Smoothly walks and turns the player toward the stand spot. */
    private void moveToward(Player p, Session s, Location stand) {
        Location cur = p.getLocation();
        double dx = stand.getX() - cur.getX();
        double dz = stand.getZ() - cur.getZ();
        double dy = s.forward ? 0 : stand.getY() - cur.getY();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        Location next = cur.clone();
        boolean changed = false;

        if (dist > 0.02) {
            double step = Math.min(MOVE_STEP, dist);
            next.add(dx / dist * step, dy / dist * step, dz / dist * step);
            changed = true;
        }

        float targetYaw = s.forward ? yawOf(s.face) : cur.getYaw();
        float targetPitch = s.forward ? 25f : 80f;
        float newYaw = approachAngle(cur.getYaw(), targetYaw, YAW_STEP);
        float newPitch = approach(cur.getPitch(), targetPitch, PITCH_STEP);
        if (newYaw != cur.getYaw() || newPitch != cur.getPitch()) {
            next.setYaw(newYaw);
            next.setPitch(newPitch);
            changed = true;
        }

        if (changed) p.teleport(next);
    }

    private void tick(Player p, Session s) {
        if (!p.isOnline() || p.isDead() || !p.getWorld().equals(s.center.getWorld())) {
            stop(s);
            return;
        }
        Location stand = standSpot(s);
        if (p.getLocation().distance(stand) > 24) {
            halt(p, s, "you are too far from the drill");
            return;
        }
        p.setFallDistance(0f);

        if (s.autoMove) moveToward(p, s, stand);

        s.ticks++;
        if (s.ticks % SPEEDS[s.speedIndex] != 0) return;

        boolean reachable;
        if (s.autoMove) {
            reachable = gap(p.getLocation(), stand, s) <= 1.6;
        } else {
            reachable = p.getEyeLocation().distance(s.center.clone().add(0.5, 0.5, 0.5)) <= 5.5;
        }
        if (!reachable) {
            p.sendActionBar(Component.text(s.autoMove ? "Moving into position..." : "Out of reach - step closer",
                    NamedTextColor.YELLOW));
            return;
        }

        World w = s.center.getWorld();
        if (!s.forward && s.center.getBlockY() <= w.getMinHeight()) {
            halt(p, s, "reached the bottom of the world");
            return;
        }
        if (s.forward && s.center.getBlockY() + s.size >= w.getMaxHeight()) {
            halt(p, s, "reached the build height limit");
            return;
        }
        if (sliceHasLava(s)) {
            halt(p, s, "lava ahead");
            return;
        }

        digSlice(p, s);
        p.playSound(p.getLocation(), Sound.BLOCK_STONE_BREAK, 0.6f, 0.6f);

        if (s.forward) {
            s.center.add(s.face.getModX(), 0, s.face.getModZ());
        } else {
            s.center.subtract(0, 1, 0);
        }
        p.sendActionBar(Component.text("Drilling " + s.size + "x" + s.size + "...  " + s.dug + " blocks",
                NamedTextColor.GOLD));
    }

    /** Block in the current slice. a and b both run from -half..half. */
    private Block sliceBlock(Session s, int a, int b) {
        World w = s.center.getWorld();
        int cx = s.center.getBlockX(), cy = s.center.getBlockY(), cz = s.center.getBlockZ();
        int half = s.size / 2;
        if (!s.forward) {
            return w.getBlockAt(cx + a, cy, cz + b);
        } else if (s.face == BlockFace.NORTH || s.face == BlockFace.SOUTH) {
            return w.getBlockAt(cx + a, cy + b + half, cz);
        } else {
            return w.getBlockAt(cx, cy + b + half, cz + a);
        }
    }

    private boolean sliceHasLava(Session s) {
        int half = s.size / 2;
        for (int a = -half; a <= half; a++) {
            for (int b = -half; b <= half; b++) {
                if (sliceBlock(s, a, b).getType() == Material.LAVA) return true;
            }
        }
        return false;
    }

    private void digSlice(Player p, Session s) {
        ItemStack tool = new ItemStack(Material.NETHERITE_PICKAXE);
        int half = s.size / 2;
        for (int a = -half; a <= half; a++) {
            for (int b = -half; b <= half; b++) {
                breakBlock(p, s, sliceBlock(s, a, b), tool);
            }
        }
    }

    private void breakBlock(Player p, Session s, Block blk, ItemStack tool) {
        if (blk.isEmpty() || blk.isLiquid()) return;
        if (blk.getType().getHardness() < 0) return;          // bedrock, barriers, etc.
        if (blk.getState() instanceof Container) return;       // never destroy chests/furnaces

        BlockBreakEvent ev = new BlockBreakEvent(blk, p);      // lets protection plugins say no
        Bukkit.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) return;

        Collection<ItemStack> drops = ev.isDropItems() ? blk.getDrops(tool, p) : List.of();
        blk.setType(Material.AIR);
        s.dug++;

        for (ItemStack drop : drops) {
            Map<Integer, ItemStack> left = p.getInventory().addItem(drop);
            for (ItemStack rest : left.values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), rest);
            }
        }
    }
}
