DRILL PLUGIN v2 (Paper server, Minecraft 1.21.11)

BUILD ON GITHUB
1. Make a new GitHub repo. Upload ALL files and folders from this zip to the TOP of the repo:
     .github/workflows/build.yml
     src/main/java/com/drill/DrillPlugin.java
     src/main/resources/plugin.yml
     build.gradle
     settings.gradle
2. Open the Actions tab and wait for the green check.
3. Open the run, scroll to Artifacts, download "drill-jar", unzip it.
4. Put the jar WITHOUT "-sources" in your server's "plugins" folder, restart the server.

USE IT
/drill opens the menu (needs op, or the permission drill.use)
 - START / STOP
 - Direction: Down or Forward
 - Size: left click bigger, right click smaller (3x3 to 15x15, only while stopped)
 - Speed: Slow / Normal / Fast / Turbo
 - Auto-move: walks and turns you smoothly when blocks are out of reach
